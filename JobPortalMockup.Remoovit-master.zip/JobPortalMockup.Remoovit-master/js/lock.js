$(document).ready(function() {
    "use strict";
    $("body").on("contextmenu",function(e){
       return false;
    }); 
});
