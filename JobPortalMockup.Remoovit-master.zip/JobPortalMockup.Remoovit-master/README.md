# JobPortalMockup.Remoovit
Job portal template, HTML + CSS + JAVASCRIPT
